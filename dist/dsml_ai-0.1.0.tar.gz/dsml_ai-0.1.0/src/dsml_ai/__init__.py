__version__ = "0.1.0"

def hello() -> str:
    """Sample function for DSML package."""
    return "Hello, DSML!"
